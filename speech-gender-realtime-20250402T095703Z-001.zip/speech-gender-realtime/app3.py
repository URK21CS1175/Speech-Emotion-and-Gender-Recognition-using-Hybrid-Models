import streamlit as st
import torch
import os
import tempfile
import speech_recognition as sr
import time
from transformers import pipeline
import io

# Set page config
st.set_page_config(
    page_title="Speech Analysis App",
    page_icon="🎵",
    layout="centered"
)

# Initialize models
@st.cache_resource
def load_gender_model():
    return pipeline("audio-classification", model="audeering/wav2vec2-large-robust-24-ft-age-gender")

@st.cache_resource
def load_emotion_text_model():
    return pipeline("sentiment-analysis", model="michellejieli/emotion_text_classifier")

# Function to process audio file for gender analysis
# Improved function to process audio for gender analysis
def process_audio_for_gender(audio_data, gender_model):
    # Create a temporary file
    temp_audio_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as tmp_file:
            tmp_file.write(audio_data.getvalue())
            temp_audio_path = tmp_file.name
        
        # Print debug info
        st.info(f"Processing audio file: {temp_audio_path}")
        
        # Get audio info
        import wave
        with wave.open(temp_audio_path, 'rb') as wf:
            channels = wf.getnchannels()
            sampwidth = wf.getsampwidth()
            framerate = wf.getframerate()
            st.write(f"Audio properties: Channels={channels}, Sample Width={sampwidth}, Rate={framerate}")
        
        # Process with gender model
        gender_results = gender_model(temp_audio_path)
        
        # Print results for debugging
        print("Gender model raw results:", gender_results)
        
        # Remove temp file
        if temp_audio_path and os.path.exists(temp_audio_path):
            os.unlink(temp_audio_path)
        
        return gender_results
    except Exception as e:
        # Remove temp file in case of error
        if temp_audio_path and os.path.exists(temp_audio_path):
            os.unlink(temp_audio_path)
        print(f"Error in gender processing: {e}")
        st.error(f"Audio processing error: {e}")
        raise e

# Function to convert speech to text
def speech_to_text(audio_data):
    """Convert speech audio to text using Google's speech recognition"""
    r = sr.Recognizer()
    temp_audio_path = None
    
    try:
        # Create temporary file for the audio
        with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as temp_audio_file:
            temp_audio_path = temp_audio_file.name
            
        # Write audio data to the temporary file
        with open(temp_audio_path, 'wb') as f:
            f.write(audio_data.getvalue())
        
        # Use speech recognition on the file
        with sr.AudioFile(temp_audio_path) as source:
            audio = r.record(source)
            text = r.recognize_google(audio)
        
        # Clean up the temporary file
        if temp_audio_path and os.path.exists(temp_audio_path):
            os.unlink(temp_audio_path)
        
        return text
    except sr.UnknownValueError:
        return "Speech not recognized"
    except sr.RequestError as e:
        return f"Speech recognition service error: {e}"
    except Exception as e:
        if temp_audio_path and os.path.exists(temp_audio_path):
            os.unlink(temp_audio_path)
        return f"Error: {str(e)}"

# Function to display analysis results
# Updated display_results function with better gender detection logic
def display_results(gender_results, text=None, text_emotion_results=None):
    # Display results in columns
    if text_emotion_results:
        col1, col2 = st.columns(2)
    else:
        col1 = st.container()
    
    # Gender results
    with col1:
        st.subheader("Gender Analysis")
        
        # Filter for gender-related labels
        female_entries = [entry for entry in gender_results if 'female' in entry['label'].lower()]
        male_entries = [entry for entry in gender_results if 'male' in entry['label'].lower()]
        
        # Calculate total probability for each gender
        female_probability = sum(entry['score'] for entry in female_entries)
        male_probability = sum(entry['score'] for entry in male_entries)
        
        # Determine gender based on higher probability
        if female_probability > male_probability:
            gender = 'Female'
            confidence = female_probability / (female_probability + male_probability) * 100
        else:
            gender = 'Male'
            confidence = male_probability / (female_probability + male_probability) * 100
        
        # Display result with a clean, simple interface
        st.markdown(f"### {gender}")
        st.markdown(f"Confidence: {confidence:.0f}%")
        st.progress(confidence/100)
        
    # Text Emotion results (if available)
    if text_emotion_results:
        with col2:
            st.subheader("Emotion Analysis")
            
            # Display transcribed text
            st.markdown("Transcribed Text:")
            st.markdown(f"\"{text}\"")
            
            # Display emotion from text
            emotion = text_emotion_results[0]['label']
            confidence = text_emotion_results[0]['score'] * 100
            
            st.markdown(f"Detected Emotion: {emotion.capitalize()}")
            st.markdown(f"Confidence: {confidence:.0f}%")
            
            # Display progress bar
            st.progress(confidence/100)
            
            # Map emotions to emojis
            emoji_map = {
                'joy': '😊', 'sadness': '😢', 'anger': '😠', 
                'neutral': '😐', 'fear': '😨', 'disgust': '🤢',
                'surprise': '😲'
            }
            
            # Display emoji if we have a mapping
            if emotion in emoji_map:
                st.markdown(f"# {emoji_map[emotion]}")
    
    # Show all details in expander
    with st.expander("View All Details"):
        st.write("Gender Model Results:", gender_results)
        if text_emotion_results:
            st.write("Text Emotion Results:", text_emotion_results)

def record_audio(duration=5):
    """Record audio for the specified duration"""
    # Initialize recognizer
    r = sr.Recognizer()
    
    # Create a placeholder for the recording status
    status_placeholder = st.empty()
    status_placeholder.info(f"Preparing to record for {duration} seconds...")
    
    # Use the default microphone as the audio source
    with sr.Microphone() as source:
        # Adjust for ambient noise
        status_placeholder.info("Adjusting for ambient noise... Please wait.")
        r.adjust_for_ambient_noise(source, duration=1)
        
        # Start recording
        status_placeholder.warning("🔴 Recording... Speak now!")
        audio_data = r.record(source, duration=duration)
        status_placeholder.success("✅ Recording completed!")
    
    # Convert the audio data to WAV format
    # SpeechRecognition AudioData to WAV file
    temp_audio_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as temp_audio_file:
            temp_audio_path = temp_audio_file.name
            
        # Write audio data to the temporary file
        with open(temp_audio_path, 'wb') as f:
            f.write(audio_data.get_wav_data())
        
        # Read the file back into a BytesIO object
        with open(temp_audio_path, 'rb') as f:
            wav_data = io.BytesIO(f.read())
        
        # Clean up the temporary file
        if temp_audio_path and os.path.exists(temp_audio_path):
            os.unlink(temp_audio_path)
        
        return wav_data
    except Exception as e:
        if temp_audio_path and os.path.exists(temp_audio_path):
            os.unlink(temp_audio_path)
        raise e

# Main application
def main():
    st.title("🎵 Speech Gender and Text Emotion Analysis")
    
    st.markdown("""
    ### Realtime Audio Analysis
    Record your voice to analyze your speech:
    
    1. Select recording duration
    2. Choose whether to analyze text content
    3. Click "Start Recording" and speak clearly
    4. Review the analysis results
    """)
    
    # Recording duration slider
    duration = st.slider("Recording Duration (seconds)", 3, 10, 5)
    
    # Text emotion detection checkbox with a unique key
    analyze_text = st.checkbox("Analyze speech content (text emotion)", value=True, key="analyze_text_checkbox")
    
    # Start recording button
    if st.button("Start Recording"):
        try:
            # Record audio
            with st.spinner(f"Recording for {duration} seconds..."):
                audio_data = record_audio(duration)
            
            # Allow user to play back the recording
            st.audio(audio_data)
            
            # Process the recording
            with st.spinner("Analyzing audio..."):
                # Load gender model
                gender_model = load_gender_model()
                
                # Process audio for gender
                gender_results = process_audio_for_gender(audio_data, gender_model)
                
                # Process text if enabled
                text = None
                text_emotion_results = None
                
                if analyze_text:
                    # First convert speech to text
                    with st.spinner("Transcribing speech to text..."):
                        text = speech_to_text(audio_data)
                        
                    if text and text != "Speech not recognized":
                        # Then analyze text emotion
                        text_emotion_model = load_emotion_text_model()
                        text_emotion_results = text_emotion_model(text)
                
                # Display results
                display_results(gender_results, text, text_emotion_results)
                
        except Exception as e:
            st.error(f"Error recording or processing audio: {str(e)}")
            st.info("Please make sure your microphone is connected and try again.")

if __name__ == "__main__":
    main()